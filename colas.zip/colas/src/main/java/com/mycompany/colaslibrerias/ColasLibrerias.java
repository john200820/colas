/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.colas;

/**
 *
 * @author ESTUDIANTES
 */
public class Colas {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
